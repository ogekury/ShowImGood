$(document).ready(function() {
    map.init();
    dom.init();
});



